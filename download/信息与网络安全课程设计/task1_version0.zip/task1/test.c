#include<stdio.h>
#include<stdlib.h>
#include<pcap.h>



int main()
{
    char errbuf[PCAP_ERRBUF_SIZE];
    const char *device = pcap_lookupdev(errbuf);
    if (device == NULL) {
    fprintf(stderr, "Error: %s\n", errbuf);
    return 1;
    }
    printf("Device: %s\n", device);

    pcap_t *handle = pcap_open_live(device, 65536, 1, 1000, errbuf);
    if (handle == NULL) {
    fprintf(stderr, "Error opening device: %s\n", errbuf);
    return 1;
    }
}