#include <string.h>
#include <stdlib.h>
#include <pcap.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include "packet_header.h"
#include <sys/types.h>

//#define _DBG_PKT
//#define _DBG_ETH
//#define _DBG_IP
//#define _DBG_TCP

#define FTP_CMD_PORT	"PORT "
#define FTP_CMD_PASV	"PASV"
#define FTP_CMD_LIST	"LIST"
#define FTP_CMD_RETR	"RETR "
#define FTP_CMD_STOR	"STOR "

#define FTP_DATA_CMD_LIST	1
#define FTP_DATA_CMD_RETR	2
#define FTP_DATA_CMD_STOR	3
static __u32 ftp_data_cmd = 0;
static char ftp_filename[256];

#define FTP_DATA_MODE_PORT	1
#define FTP_DATA_MODE_PASV	2
static __u32 ftp_data_mode = 0;

static __u32 ftp_data_listen_ip = 0;
static __u16 ftp_data_listen_port = 0;

#define DBG printf
#ifndef NIPQUAD
#define NIPQUAD(addr) \
	((__u8 *)&addr)[0], \
	((__u8 *)&addr)[1], \
	((__u8 *)&addr)[2], \
	((__u8 *)&addr)[3]
#endif // NIPQUAD

#include <openssl/md5.h>  // 用于文件哈希校验

// TCP会话结构体（用于数据重组）
typedef struct TcpSession {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint16_t src_port;
    uint16_t dst_port;
	uint32_t isServer;		// 记录当前的方向 C->S 0 S->C 1
    uint32_t seq;        // 当前序列号
    uint32_t next_seq;   // 期望的下一个序列号
    uint8_t *data;       // 数据缓冲区
    size_t data_len;     // 数据总长度
    struct TcpSession *next;
} TcpSession;

static TcpSession *session_list = NULL;  // 全局会话链表
static char output_dir[256] = "."; // 重组文件输出目录

void print_all_sessions() {
    TcpSession *sess = session_list;
    while (sess) {
        printf("========================================\n");
        printf("Session:\n");
        printf("  Source IP: %u.%u.%u.%u\n", NIPQUAD(sess->src_ip));
        printf("  Destination IP: %u.%u.%u.%u\n", NIPQUAD(sess->dst_ip));
        printf("  Source Port: %u\n", sess->src_port);
        printf("  Destination Port: %u\n", sess->dst_port);
        printf("  Next Expected Seq: %u\n", sess->next_seq);
		printf("  IsServer:%u", sess->isServer);
        printf("  Data Length: %zu bytes\n", sess->data_len);
        sess = sess->next;
    }
    printf("========================================\n");
}

//transform "a1,a2,a3,a4,a5,a6" to IP and port
int get_ftp_data_addr(const char *addrstr)
{
	__u32 a1, a2, a3, a4, a5, a6;
	char ipstr[20];
	struct in_addr in;

	if (addrstr == NULL)
		goto errout;

	sscanf(addrstr, "%u,%u,%u,%u,%u,%u", &a1, &a2, &a3, &a4, &a5, &a6);
	sprintf(ipstr, "%u.%u.%u.%u", a1, a2, a3, a4);
	if (inet_aton(ipstr, &in) < 0)
		goto errout;

	ftp_data_listen_ip = in.s_addr;
	ftp_data_listen_port = a5 * 256 + a6;
	return 0;

  errout:
	ftp_data_listen_ip = 0;
	ftp_data_listen_port = 0;
	return -1;
}

void ftp_ctrl_proc(int dir, const u_char * ftp_msg, __u32 msg_len)
{
	const char *addrstr = NULL;

	if (msg_len == 0)
		return;
	//判断主动模式还是被动模式
	if (strncmp(ftp_msg, FTP_CMD_PORT, strlen(FTP_CMD_PORT)) == 0) {
		//"PORT a1,a2,a3,a4,a5,a6
		addrstr = ftp_msg + strlen(FTP_CMD_PORT);
		if (get_ftp_data_addr(addrstr) == 0) {
			ftp_data_mode = FTP_DATA_MODE_PORT;
			DBG("***** FTP DATA Mode: %d, Server: %u.%u.%u.%u:%u\n", ftp_data_mode, NIPQUAD(ftp_data_listen_ip), ftp_data_listen_port);
		}
	} else if (strncmp(ftp_msg, "227", strlen("227")) == 0) {
		//"227 Entering Passive Mode (a1,a2,a3,a4,a5,a6)"
		addrstr = strchr(ftp_msg, '(');
		if (addrstr != NULL) {
			addrstr++;
			if (get_ftp_data_addr(addrstr) == 0) {
				ftp_data_mode = FTP_DATA_MODE_PASV;
				DBG("***** FTP DATA Mode: %d, Server: %u.%u.%u.%u:%u\n", ftp_data_mode, NIPQUAD(ftp_data_listen_ip), ftp_data_listen_port);
			}
		}
	}

	//判断数据传输命令
	//RETR <filename>从server下载文件到client
	//STOR <filename>上传文件到服务器
	if (ftp_data_mode) {
		if (strncmp(ftp_msg, FTP_CMD_LIST, strlen(FTP_CMD_LIST)) == 0) {
			ftp_data_cmd = FTP_DATA_CMD_LIST;
			bzero(ftp_filename, sizeof(ftp_filename));
		} else if (strncmp(ftp_msg, FTP_CMD_RETR, strlen(FTP_CMD_RETR)) == 0) {
			ftp_data_cmd = FTP_DATA_CMD_RETR;
			bzero(ftp_filename, sizeof(ftp_filename));
			strncpy(ftp_filename, ftp_msg + strlen(FTP_CMD_RETR), msg_len - strlen(FTP_CMD_RETR) - 2);	//exclude tail "\r\n"
			DBG("***** Get file %s\n", ftp_filename);
		} else if (strncmp(ftp_msg, FTP_CMD_STOR, strlen(FTP_CMD_STOR)) == 0) {
			ftp_data_cmd = FTP_DATA_CMD_STOR;
			bzero(ftp_filename, sizeof(ftp_filename));
			strncpy(ftp_filename, ftp_msg + strlen(FTP_CMD_STOR), msg_len - strlen(FTP_CMD_STOR) - 2);	//exclude tail "\r\n"
			DBG("***** Put file %s\n", ftp_filename);
		}
	}
	return;
}

// 创建或获取TCP会话
TcpSession* get_or_create_session(uint32_t src_ip, uint32_t dst_ip, uint16_t src_port, uint16_t dst_port) {
    TcpSession *curr = session_list;
    while (curr) {
        if (curr->src_ip == src_ip && curr->dst_ip == dst_ip &&
            curr->src_port == src_port && curr->dst_port == dst_port) {
            return curr;
        }
        curr = curr->next;
    }

    // 新建会话
    TcpSession *new_sess = (TcpSession*)malloc(sizeof(TcpSession));
    new_sess->src_ip = src_ip;
    new_sess->dst_ip = dst_ip;
    new_sess->src_port = src_port;
    new_sess->dst_port = dst_port;
    new_sess->next_seq = 0;
    new_sess->data = NULL;
    new_sess->data_len = 0;
    new_sess->next = session_list;
    session_list = new_sess;
    return new_sess;
}

// 释放会话资源
void free_session(TcpSession *sess) {
    if (sess->data) free(sess->data);
    free(sess);
}
void tcp_proc(const u_char * tcp_pkt, __u32 pkt_len, __u32 srcip, __u32 dstip)
{
	TCPHdr_t *tcph = (TCPHdr_t *) tcp_pkt;
	
	if (ntohs(tcph->dest) == 21) {
		ftp_ctrl_proc(0, tcp_pkt + tcph->doff * 4, pkt_len - tcph->doff * 4);
		return;
	} else if (ntohs(tcph->source) == 21) {
		ftp_ctrl_proc(1, tcp_pkt + tcph->doff * 4, pkt_len - tcph->doff * 4);
		return;
	}
    uint16_t src_port = ntohs(tcph->source);
    uint16_t dst_port = ntohs(tcph->dest);
	/* FTP data connection process */
	uint32_t isServer = (dstip == ftp_data_listen_ip && dst_port == ftp_data_listen_port);
	uint32_t isClient = (srcip == ftp_data_listen_ip && src_port == ftp_data_listen_port);

    if (ftp_data_mode && (isClient||isServer )) 
	{
        TcpSession *sess = get_or_create_session(srcip, dstip, src_port, dst_port);
        uint32_t seq = ntohl(tcph->seq);
        uint32_t payload_len = pkt_len - tcph->doff * 4;
        const u_char *payload = tcp_pkt + tcph->doff * 4;
        sess->seq = seq;
        sess->data = realloc(sess->data, sess->data_len + payload_len);
        memcpy(sess->data + sess->data_len, payload, payload_len);
        sess->data_len += payload_len;
        sess->next_seq = seq + payload_len;
		sess->isServer = isServer;
    }
	/* Add your code here */
	return;
};

void ip_proc(const u_char * ip_pkt, __u32 pkt_len)
{
	IPHdr_t *iph = (IPHdr_t *) ip_pkt;
	if (iph->protocol == IPPROTO_TCP) {
		tcp_proc(ip_pkt + iph->ihl * 4, ntohs(iph->tot_len) - iph->ihl * 4, iph->saddr, iph->daddr);
		return;
	}

	return;
}

void pkt_proc(u_char * arg, const struct pcap_pkthdr *pkthdr, const u_char * packet)
{
	int i = 0;
	EthHdr_t *eth = (EthHdr_t *) packet;
	if (ntohs(eth->h_type) == 0x0800) {
		ip_proc(packet + sizeof(EthHdr_t), pkthdr->len - sizeof(EthHdr_t));
		return;
	}
	return;
}

void usage(const char *appname)
{
	printf("Usage:\n");
	printf("\t%s <pcap filename>\n", appname);
	return;
}

void process_file()
{
	char filename[512];
	snprintf(filename, sizeof(filename), "%s/%s", output_dir, ftp_filename);
	FILE *fp = fopen(filename, "wb+");
	printf("ftp_data_cmd:%d\n",ftp_data_cmd);
	if(FTP_DATA_CMD_RETR == ftp_data_cmd)//从server下载文件到client
	{
		if (fp) {
			TcpSession* sess = session_list;
			while(sess)
			{
				if(sess->isServer)
				{
					fwrite(sess->data, 1, sess->data_len, fp);
				}
				sess = sess->next;
			}
			fclose(fp);
		}
		// 释放会话
		TcpSession *current = session_list;
		while(current != NULL) {
			TcpSession *next_session = current->next;
			free_session(current);
			current = next_session;
		}
		session_list = NULL;
		return;
	}
	else if(FTP_DATA_CMD_STOR == ftp_data_cmd)//从client上传文件到server
	{
		if (fp) {
			TcpSession* sess = session_list;
			while(sess)
			{
				printf("sess->isServer:%d\n",sess->isServer);
				if(!sess->isServer)
					fwrite(sess->data, 1, sess->data_len, fp);
				sess = sess->next;
			}
			fclose(fp);
		}
		// 释放会话
		TcpSession *current = session_list;
		while(current != NULL) {
			TcpSession *next_session = current->next;
			free_session(current);
			current = next_session;
		}
		session_list = NULL;
		return;
	}
}

int main(int argc, char **argv)
{
	char *pfile;
	pcap_t *pd = NULL;
	char ebuf[PCAP_ERRBUF_SIZE];
	int count = 0;

	if (argc != 2) {
		usage(argv[0]);
		return -1;
	}

	pfile = argv[1];
	printf("pcap file: %s\n", pfile);

	/*
	 * Open a saved pcap file
	 */
	pd = pcap_open_offline(pfile, ebuf);
	if (pd == NULL) {
		printf("Open pcap file failed (%s)\n", ebuf);
		return -1;
	}

	/*
	 * Loop forever & process each packet 
	 */
	pcap_loop(pd, -1, pkt_proc, (u_char *) & count);

	// 写入文件
	print_all_sessions();
	process_file();
	printf("============================================================\n");
	printf("Total %d packets are analyzed.\n\n", count);
	pcap_close(pd);
	return 0;
}
