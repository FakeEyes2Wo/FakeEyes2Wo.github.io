

gcc $1 -o mydebug.o -g -lpcap
gdb --args mydebug.o $2

